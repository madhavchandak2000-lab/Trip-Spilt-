TripSplit - Android APK banane ka tareeka (free, phone se bhi ho jata hai)

1. github.com par free account banao -> New repository (naam: tripsplit) -> Create.
2. "uploading an existing file" par click karo. Is zip ko khol ke uske ANDAR ka sara content
   (www, launcher, .github, package.json, capacitor.config.json, .gitignore) drag-drop karo.
   Dhyan: ".github" folder bhi upload hona chahiye. Agar drag-drop me hidden folder na jaye,
   to laptop par GitHub Desktop use karo ya "Add file > Create new file" me
   ".github/workflows/build-apk.yml" naam se file bana ke uska content paste karo.
3. Commit karo. Upar "Actions" tab me "Build Android APK" chalna shuru hoga (5-8 minute).
4. Green tick aane par us run par click karo -> neeche "Artifacts" me "TripSplit-APK" download karo.
   Zip khol ke app-debug.apk nikalo.
5. APK phone me bhejo -> kholo -> "Install unknown apps" allow karo -> Install.

Data phone ke andar hi save hota hai. Backup & Data se JSON export karte raho.
